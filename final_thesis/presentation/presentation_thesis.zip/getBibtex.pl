#!/usr/bin/env perl

# If your perl-interpreter is not /usr/bin/perl, then
# set in the first line your perl-interpreter.

$|=1;

use strict;
use Getopt::Long;
require LWP::UserAgent;

# written by Vinh Hong
# $Id: getBibtex.pl 611 2020-03-15 18:38:53Z droege $
# History:
#  2004-01-20 Dr	allow limits for number of refs per call and length
#  2009-04-15 Dr	change DB access for new CMS, keep old method as option
#  2009-07-10 Dr	don't overwrite .bib file if access to server failed
#  2013-03-18 Dr	new URL
#  2018-09-05 Dr	remove '%%' from first output line, biber fails on it (drops first record)
#  2019-09-12 Dr	new URL
#  2020-03-15 Dr	fix postprocessing. no more <pre> in output, so don't drop chars

# configuration section: =====================================================

  my $URL = "https://www.uni-koblenz-landau.de/de/koblenz/publikationen/bib.php";
  my $URLkey = "litkeys";
  my $proxy = "";
  my $bibtexFile = "myref.bib";
  my $maxUrlLen = 1000;		# doesn't work yet
  my $maxRefsPerCall = 32;	# set to 1 for 1 call per ref
  my $usePost = 0;		# will use GET if 0, POST if 1
  my $Verbose = 0;
  my $OldCMS = 0;

# end configuration section ==================================================

&Main();

# *********************************************************************
# * Unterroutinen                                                     *
# *********************************************************************

sub Main
{
  my ($optProxy);
  my ($optBibtexFile);
  my ($optHelp);
  my ($optNumRefs);
  my ($optOldCMS);
  my ($optVerbose);

  GetOptions("proxy=s" => \$optProxy,
     "bibfile=s" => \$optBibtexFile,
     "numrefs=i" => \$optNumRefs,
     "oldcms" => \$optOldCMS,
     "verbose" => \$optVerbose,
     "help" => \$optHelp);

  if (($optHelp) || !(@ARGV))
  {
    die "$0 [--proxy=PROXYURL] [--bibfile=BIBFILE] [--numrefs=NUM] [--help] [--oldcms] [--verbose] <bib-keys>\n";
  }

  if ($optVerbose)
  {
    $Verbose = $optVerbose;
  }

  if ($optOldCMS)
  {
    $OldCMS = $optOldCMS;
    $URL = "http://www.uni-koblenz.de/FB4/Publications/LitDB/scripts/search";
    $usePost = 1;		# will use GET if 0, POST if 1
  }

  if ($optProxy)
  {
    $proxy = $optProxy;
  }
  print "Proxy: $proxy\n" if ($Verbose);

  if ($optBibtexFile)
  {
    $bibtexFile = $optBibtexFile;
  }
  print "bibtexFile: $bibtexFile\n" if ($Verbose);
  if ($optNumRefs)
  {
    $maxRefsPerCall = $optNumRefs;
  }
  $maxRefsPerCall = 1 if ($maxRefsPerCall < 1);
  print "maxRefsPerCall: $maxRefsPerCall\n" if ($Verbose);

  open (BIB, ">$bibtexFile.tmp") || die "can't create BIB file '$bibtexFile'\n";
  if ($optNumRefs || ! $usePost) {# deal with limited URL length for GET method
    while (@ARGV > $maxRefsPerCall) {
      my @part = splice (@ARGV, 0, $maxRefsPerCall);
      fetchRefs (\*BIB, @part);
    }
  }
  fetchRefs (\*BIB, @ARGV);	# fetch rest (or all for POST method)
  close (BIB);
  if ( (-s "$bibtexFile.tmp") > 0) {
    unlink ($bibtexFile);
    rename ("$bibtexFile.tmp", $bibtexFile);
  }
  else {
    unlink ("$bibtexFile.tmp");
    print STDERR "Could not access LitDB server, keeping old .bib file\n";
  }

  print "Written into: $bibtexFile\n" if ($Verbose);
}

sub fetchRefs {
  my $file = shift;
  my @args = @_;

  my ($Request, $Response, $UserAgent);
  my ($i, $quotedRefs, $queryArg);

  return unless (@args);

  if ($OldCMS) {
    $quotedRefs = join (",", map { "'$_'" } @args);	# (a b) -> 'a','b'
    $queryArg = "$URLkey=" . "[" . $quotedRefs . "]";
  }
  else {
    $quotedRefs = join (",", @args);			# (a b) -> a,b
    $queryArg = "$URLkey=" . $quotedRefs;
  }
  print "Refs: $quotedRefs\n" if ($Verbose);

  $UserAgent = new LWP::UserAgent ("env_proxy" => 1 );
  $UserAgent->proxy("http", "$proxy") if $proxy;
  $UserAgent->timeout(30);
  # $UserAgent->default_headers->push_header("Accept-Charset" => "iso-8859-1");

  printf "POST or GET: %s ($usePost)\n", (($usePost) ? "POST" : "GET") if ($Verbose);

  if ($usePost) {
    my $postContent = $queryArg;
    my $hdr = undef;
    $Request = new HTTP::Request("POST", $URL, $hdr, $postContent);
  }
  else {
    my $getURL = $URL . "?$queryArg";
    $Request = new HTTP::Request("GET", $getURL);
    print "GET: $getURL\n" if ($Verbose);
  }
  $Response = $UserAgent->request($Request);

  if ($Response->is_success) {
      my $Resp = $Response->content;
      $Resp =~ s:^<pre>::; # 2009-2019 response was enclosed by <pre>...</pre>
      $Resp =~ s:</pre>$::;
      print $file "", $Resp, "\n";
  }
  else {
    print STDERR "Access failed\n";
  }
}
1;
