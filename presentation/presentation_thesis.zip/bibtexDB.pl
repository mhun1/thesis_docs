#!/usr/bin/env perl

# wrapper around BibTeX
# called in place of bibtex, e.g. in Makefiles to TeX documents.
# It will (recursively) scan a given .aux file, generate a
# dummy .aux file with all \citation{XYZ} and a \bibdata{dummy}
# dummy.bib will be filled with the entries fetched from the database.
# then bibtex will be called to process th dummy files and the resulting
# dummy.bbl will be renamed to <base>.bbl where <base> is the base name
# of the initial .aux file.
#
# January 2003, D. Droege, droege@uni-koblenz.de

#  $Id: bibtexDB.pl 595 2018-09-05 09:11:34Z droege $
# v 1.00 2004-01-20 Dr	initial version
# v 1.01 2004-01-20 Dr	keep bib file as db-refs.bib, handle bibtex options
# v 1.02 2004-02-?? VH	offline option
# v 1.03 2004-04-28 Dr	added option to specify filename of bib file
# v 1.04 2005-03-23 Dr	don't discard local bib-files
# v 1.05 2005-03-23 Dr	collect bibdata entries if they occur in several aux files
# v 1.06 2006-06-20 Dr	avoid duplicate file nams in \bibdata{...,...}
# v 1.07 2009-04-29 Dr	take -oldcms option and hand it to getBibtex.pl
# v 1.08 2010-07-01 Dr	split A,B cites to avoid duplicates in .bib file.
# v 1.09 2018-09-10 Dr	add option to run biber instead of latex, match '\abx@aux@cite'

use strict;

my $bibStyle = '';
my $bibData = '';
my $Verbose = 0;
my $FetchOnly = 0;
Main();
exit (0);

# *********************************************************************
# * Unterroutinen                                                     *
# *********************************************************************

sub mySystem {
    my $cmd = shift;
    
    print STDERR "CALL: $cmd\n" if $Verbose;	# for debugging
    return system ($cmd);
}

sub remDups {	# remove duplicate file names from bib file list (to calm bibtex)
    my $bLstStr = shift;
    my %bFound = ();
    my $bn;
    my $bRes = "";
    
    return $bLstStr unless (index ($bLstStr, ",") >= 0);
    my @bNames = split (/,/, $bLstStr);
    foreach $bn (@bNames) {
      $bRes .= ",$bn" unless ($bFound{$bn});
      $bFound{$bn} = 1;
    }
    substr ($bRes, 0, 1) = "";
    return $bRes;
}

sub Main
{
    my $tmp = "_tmp_${$}_";	# base name for dummy files
    my $usage = "usage: bibtexDB.pl [-v] [-offline] [-fetchonly] [-oldcms] [-bibfile=file.bib] [bibtex-options] aux-file\n";
    my $bibfile = "db-refs.bib";
    my $bibOpts = "";
    my $ref;
    my $bibbase;
    my $Offline = 0;
    my $UseOldCMS = 0;
    
    # read and store bibtex options
    while ($ARGV[0] =~ m/^-/) {
	    if ($ARGV[0] =~ m/^-v/) { $Verbose = 1; shift @ARGV; next; }
	    if ($ARGV[0] =~ m/^-offline/) { $Offline = 1; shift @ARGV; next; }
	    if ($ARGV[0] =~ m/^-oldcms/) { $UseOldCMS = 1; shift @ARGV; next; }
	    if ($ARGV[0] =~ m/^-fetchonly/) { $FetchOnly = 1; shift @ARGV; next; }
	    if ($ARGV[0] =~ m/^-bibfile=(.*)/) { $bibfile = $1; shift @ARGV; next; }
	    $bibOpts .= " " . shift (@ARGV);
    }
    $bibbase = $bibfile;
    $bibbase =~ s/\.bib$//;
    
    die "wrong number of arguments\n  $usage" unless (@ARGV == 1);
    my $auxFile = $ARGV[0] . ".aux";
    $auxFile .= ".aux" if ((! -r $auxFile) && (-r "$auxFile.aux"));
    die "can't read aux-file '$auxFile'\n  $usage" unless (-r $auxFile);
    
    # scan .aux files for reference entries (sets $bibStyle if found)
    my @refs = scanAux ($auxFile);
    $bibbase .= $bibData;
    $bibbase = remDups ($bibbase);
    
    # fetch entries from database and write them in $bibfile.bib
    if ($Offline == 0)
    {
      my ($cmsFlag) = ($UseOldCMS) ? "-oldcms" : "";
      mySystem ("getBibtex.pl --bibfile=$bibfile $cmsFlag '" . join ("' '", @refs) . "'");
    }
    
    # generate $tmp.aux with style-, data- and citation entries
  if (! $FetchOnly) {
    $bibStyle = "\\bibstyle{alpha}\n" unless $bibStyle;
    open (DAUX, ">$tmp.aux") || warn "can't create temp aux file '$tmp.aux'\n";
    print DAUX "$bibStyle";
    print DAUX "\\bibdata{$bibbase}\n";
    foreach $ref (@refs) { print DAUX "\\citation{$ref}\n"; }
    close (DAUX);
    
    # run bibtex on dummy ($tmp) files
    mySystem ("bibtex -min-crossrefs=1 $bibOpts $tmp");	# should generate $tmp.bbl
    
    # rename dummy-bbl file to reqired name
    my $auxBase = $auxFile;
    $auxBase =~ s/\.aux$//;	# strip suffix if present
    unlink ("$auxBase.bbl") if (-f "$auxBase.bbl");	# drop old file
    rename ("$tmp.bbl", "$auxBase.bbl");
    rename ("$tmp.blg", "$auxBase.blg");
    
    # clean up
    unlink ("$tmp.aux");
  }
}

sub scanAux {
    my $afile = shift;
    my %aDone = ();
    my %aRefs = ();
    my @aList = ($afile);
    my $af;
    
    while ($af = shift @aList) {
    	next if ($aDone{$af});
	open (AUX, $af) || warn "can't open '$af' for reading\n";
	while (<AUX>) {
	    $bibStyle = $_ if ((! $bibStyle) && m|\\bibstyle\{|);
	    if (m:\\(citation|bibcite|abx\@aux\@cite)\{([^\}]+)\}:) {
	      my $keys = $2;
	      if ($keys =~ /,/) {
	        my @k = split(/,\s*/, $keys);
		map { $aRefs{$_} = 1; } @k;
	      }
	      else {
	        $aRefs{$keys} = 1;
	      }
	    }
	    # $aRefs{$1} = 1 if (m|\\bibcite\{([^\}]+)\}|);
	    $bibData .= ",$1" if (m|\\bibdata\{([^\}]+)\}|);
	    push (@aList, $1) if ((m|\\\@input\{([^\}]+\.aux)\}|) && (! $aDone{$1}));
	}
	close (AUX);
	$aDone{$af} = 1;
    }
    
    return sort(keys(%aRefs));
}

