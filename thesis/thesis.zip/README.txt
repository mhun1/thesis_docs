*** Vorlage für Abschlussarbeiten ***

Bitte unbedingt den Leitfaden für Abschlussarbeiten lesen!
Er findet sich auf den Webseiten der Arbeitsgruppe unter "Qualifikationsarbeiten".

-------------------------------------------------------
VERWENDUNG
-------------------------------------------------------
Zum Kompilieren der Vorlage einfach in einer Linux-Shell 'make' aufrufen.

Diese Vorlage enhält zwei Perl-Skripte zur einfachen Benutzung der Literaturdatenbank LitDB des Fachbereich 4:
  bibtexDB.pl und getBibtex.pl
Diese Skripte werden automatisch von make aufgerufen. Sie durchsuchen alle TeX-Dokumente
nach \cite{}-Befehlen und versuchen die dort angegebenen Schlüssel in der LitDB zu finden.
Falls die Schlüssel gefunden wurden, werden die zugehörigen Einträge als BibTeX in die Datei
  db-refs.bib
kopiert.
Im Klartext: Für Referenzen wie folgt vorgehen:
  1. Schauen ob die Referenz in der LitDB vorhanden ist
       (https://www.uni-koblenz-landau.de/de/koblenz/fb4/publications/litdb/).
     Wenn ja, weiter bei 3.
  2. Die neue Referenz in die LitDB eintragen (dazu links auf 'Anmelden' klicken)
  3. Den Schlüssel der Referenz (z. B. Paulus2009PF) als Schlüssel für \cite-Kommandos benutzen
     (siehe Beispiel in sample-chapter.tex).
  4. make aufrufen.
     Jetzt wird automatisch db-refs.bib gefüllt
Für Referenzen, die nicht in die LitDB gehören (z. B. zu Webseiten),
sollten die BibTeX-Einträge selbst in local-refs.bib geschrieben werden.

-------------------------------------------------------
DATEIEN
-------------------------------------------------------
Folgende Dateien gehören zu dieser Vorlage:

Makefile
  Standard Unix-Makefile, mit 'make' entsteht ein pdf-Dokument via pdflatex.

README
  Diese Datei
  
abstract.tex
  TeX-File für die Kurzfassungen der Arbeit auf deutsch und englisch.
  
agasthesis.cls
  LaTeX-Klasse, die von thesis.tex benutzt wird.
  
bibtexDB.pl
  Perl-Skript, welches automatisch Einträge aus der Literaturdatenbank des FB4
  herunterlädt (liest alle \cite{} Befehle aus tex-Quellen).
  
db-refs.bib
  Hier werden die von bibtexDB.pl heruntergeladenen Referenzen als bibtex gespeichert.
  Solange noch keine Referenzen geladen wurden, ist die Datei leer.
 
local-refs.bib
  Referenzen als bibtex, die nicht in aus der LitDB heruntergeladen werden.
  
getBibtex.pl
  Hilfsprogramm für bibtexDB.pl.
  
images
  Verzeichnis für Bilder (enthält Uni- und AGAS-Logo).
  
math.pdf
  Anleitung zur Verwendung von math.sty.
  
math.sty
  Paket zur Formatierung von mathematischen Symbolen (Vektoren, Matrizen etc.).
  
sample-chapter.tex
  Beispiel-Kapitel mit Blindtext
  
thesis.tex
  Haupt-TeX-Datei, die es zu füllen gilt.
  
titlepage.tex
  Separate TeX-Datei für die Titelseite, muss für jede Arbeit angepasst werden
  
